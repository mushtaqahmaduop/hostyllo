# HOSTYLLO — Beginner Execution Guide
## 07_BEGINNER_GUIDE_v15.md
## v15.0 — Merged Solo Founder Guide
## For: Zeerak Hostix — Read at the Start of Every Work Block
## Classification: Confidential — Founder Only

> **Supersedes:** Beginner Guide v14.0, v13.0, and all prior versions.
> **What changed in v15.0:** Set B's business framing and Stage 1 pre-work merged with Set A's granular phase-by-phase execution detail. Set A's closing sections (Daily Work Habits, Financial Checkpoints, Support Operations, Legal Checklist) added.

---

## BEFORE ANYTHING ELSE — READ THIS SECTION

### The Most Important Mental Model

You are not building software. You are building a business that happens to run on software.

The goal is not a feature-complete product. The goal is:
> **5 paying clients, confirmed working, before Month 6.**

Every decision you make — what to build next, what to skip, how much to polish — must be filtered through this question:

> "Does this get me closer to 5 paying clients this week?"

If the answer is no, skip it.

### Why the Electron App Is Your Biggest Advantage

Your 50+ live hostels using the Electron app are not just customers. They are:
- Your beta testers (they will use the SaaS if you ask them)
- Your proof that the product works (wardens trust it)
- Your warm pipeline (no cold outreach needed for the first 5 clients)
- Your source of truth for every feature (don't invent things they don't use)

**Call 5 of your Electron hostel clients this week. Tell them:** "I'm building the web version with cloud backup, phone access, and automatic rent reminders. Would you be willing to try it for free and give me feedback?" Get 3 yeses before you start Phase 1.

---

## STAGE 1: PRE-WORK WEEK (Do Before Writing Code)

**Time: 1 week. These are not optional.**

### Day 1 — Apply for External Services

These have multi-week approval timelines. Apply NOW so they're ready when you need them.

**Task 1: Apply for Meta WhatsApp Business API (30 minutes)**
1. Go to business.facebook.com
2. Create a Meta Business account if you don't have one
3. Apply for WhatsApp Business Platform (not the regular WhatsApp Business app)
4. Use 360dialog as your API provider: https://360dialog.com/
5. Submit your business documents
6. Timeline: 4–8 weeks. START NOW.
7. Log this in `tasks/todo.md`: "WA application submitted: [date]"

**Task 2: Apply for Paymob Merchant Account (1 hour)**
1. Go to paymob.com (Pakistan portal)
2. Create merchant account
3. Submit business registration documents (NTN, bank account)
4. Timeline: 1–3 business days
5. Log: "Paymob application submitted: [date]"

### Day 2 — Set Up Infrastructure Accounts

**Task 3: Create all service accounts**

```bash
# Services to sign up for (all have free tiers to start):
# 1. GitHub — create hostyllo repository (private)
# 2. Railway — create account, project, set to Pro plan
# 3. Supabase — create account, create project, UPGRADE TO PRO IMMEDIATELY
#    ↑ Free tier is FORBIDDEN in production. PKR 7,000/mo is not optional.
# 4. Upstash — create Redis database
# 5. Vercel — create account
# 6. Sentry — create project "hostyllo-api"
# 7. Uptime Robot — create account
# 8. Resend — create account (email sending)
# 9. Cloudflare — create account, add hostyllo.app domain
```

**Task 4: Enable PITR on Supabase (5 minutes)**
1. Open Supabase dashboard
2. Project Settings → Database → Point-in-Time Recovery
3. Enable it. Set to 7-day retention.
4. This is the most important 5 minutes you will spend this week.

### Day 3 — Generate Secrets and Set Up Environment

**Task 5: Generate JWT RS256 keypair**

```bash
# Run this on your machine:
openssl genrsa -out jwt_private.pem 2048
openssl rsa -in jwt_private.pem -pubout -out jwt_public.pem

# Copy the content of each file
# Add to Railway environment variables:
# JWT_PRIVATE_KEY = [content of jwt_private.pem]
# JWT_PUBLIC_KEY = [content of jwt_public.pem]
# DELETE both .pem files from your machine after adding to Railway.
# NEVER commit these files to git.
```

**Task 6: Generate all other secrets**

```bash
# Generate ENCRYPTION_KEY (for CNIC + TOTP AES-256):
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
# Copy output → Railway env var: ENCRYPTION_KEY

# Store in Railway env vars (not in any file):
# SUPABASE_URL = [from Supabase project settings]
# SUPABASE_SERVICE_KEY = [from Supabase API keys — service_role key]
# REDIS_URL = [from Upstash — must start with rediss://]
# RESEND_API_KEY = [from Resend dashboard]
# SENTRY_DSN = [from Sentry project settings]
# SUPER_ADMIN_EMAIL = [your email]
# NODE_ENV = production
```

### Day 4 — Scaffold Monorepo

**Task 7: Create monorepo structure**

```bash
# Create the repository
mkdir hostyllo && cd hostyllo
git init

# Initialize pnpm workspaces
npm install -g pnpm
pnpm init

# Create workspace structure
mkdir -p apps/web apps/api apps/admin packages/db packages/ui packages/config docs tasks scripts

# Create pnpm-workspace.yaml
cat > pnpm-workspace.yaml << 'EOF'
packages:
  - 'apps/*'
  - 'packages/*'
EOF

# Create tasks files
echo "# Lessons from Claude Code sessions" > tasks/lessons.md
echo "# Current session tasks" > tasks/todo.md

# Copy your docs folder
# (Copy all files from the hostyllo_v14 docs folder into docs/)
cp /path/to/hostyllo_v14/*.md docs/

# Initial commit
git add .
git commit -m "chore: initialize monorepo structure"
```

### Day 5 — CI Pipeline + PITR Verification

**Task 8: Set up GitHub Actions CI**

```bash
mkdir -p .github/workflows
# Copy ci.yml from hostyllo_fixes/infra/ci.yml (from the uploaded hostyllo_fixes.zip)
# Copy verify-pitr.sh from hostyllo_fixes/infra/verify-pitr.sh to scripts/

chmod +x scripts/verify-pitr.sh
./scripts/verify-pitr.sh
# Must return exit code 0 before proceeding. Log the result.
echo "PITR verified: $(date)" >> tasks/lessons.md
```

**Task 9: Set up ESLint plugin**

```bash
# Copy from hostyllo_fixes/eslint/ (from uploaded hostyllo_fixes.zip)
# Place at: packages/config/eslint-plugin-hostyllo/
# Files needed:
#   index.js
#   rules/require-with-tenant.js
#   rules/no-hostel-id-from-request.js
```

**Task 10: Create setup-dev.sh for future use**

```bash
# Create scripts/setup-dev.sh — run this any time you set up a fresh machine
cat > scripts/setup-dev.sh << 'SCRIPT'
#!/bin/bash
# HOSTYLLO Development Environment Setup
# Run once on a new machine or after wiping node_modules

set -e
echo "Setting up HOSTYLLO development environment..."

# Check prerequisites
command -v node >/dev/null 2>&1 || { echo "ERROR: Node.js is required. Install from nodejs.org"; exit 1; }
command -v pnpm >/dev/null 2>&1 || { echo "Installing pnpm..."; npm install -g pnpm; }
node --version | grep -qE "v(18|20|22)" || { echo "ERROR: Node.js 18, 20, or 22 required"; exit 1; }

# Install all workspace dependencies
pnpm install

# Check env file
if [ ! -f .env.local ]; then
  cp .env.example .env.local
  echo "⚠️  Created .env.local — fill in your credentials before running"
  echo "    Required: SUPABASE_URL, SUPABASE_SERVICE_KEY, REDIS_URL, JWT_PRIVATE_KEY, JWT_PUBLIC_KEY, ENCRYPTION_KEY"
fi

# Run payment formula tests — must pass on any machine
pnpm vitest run packages/db/src/__tests__/paymentService.test.ts
echo "✅ All 14 payment tests pass"

# Verify PITR (if Supabase credentials are in env)
if grep -q "SUPABASE_URL=https" .env.local 2>/dev/null; then
  ./scripts/verify-pitr.sh && echo "✅ PITR verified" || echo "⚠️  PITR check failed — check Supabase dashboard"
fi

echo ""
echo "✅ Setup complete."
echo "   Run: cd apps/api && pnpm dev   → starts API on :3001"
echo "   Run: cd apps/web && pnpm dev   → starts web on :3000"
SCRIPT
chmod +x scripts/setup-dev.sh
git add scripts/setup-dev.sh
git commit -m "chore: add setup-dev.sh for fresh environment setup"
```

**Task 11: File migration from ZIP archives (15 minutes — do not skip)**

```bash
# Extract the required files from uploaded ZIP archives and place them at correct paths.
# This is a one-time manual operation. All these files are production-ready — do not modify them.

# From hostyllo_fixes.zip:
cp hostyllo_fixes/tests/paymentService.test.ts packages/db/src/__tests__/paymentService.test.ts
cp hostyllo_fixes/infra/ci.yml .github/workflows/ci.yml
cp hostyllo_fixes/infra/verify-pitr.sh scripts/verify-pitr.sh
chmod +x scripts/verify-pitr.sh
mkdir -p packages/config/eslint-plugin-hostyllo/rules
cp hostyllo_fixes/eslint/eslint-plugin-hostyllo/index.js packages/config/eslint-plugin-hostyllo/
cp hostyllo_fixes/eslint/eslint-plugin-hostyllo/rules/require-with-tenant.js packages/config/eslint-plugin-hostyllo/rules/
cp hostyllo_fixes/eslint/eslint-plugin-hostyllo/rules/no-hostel-id-from-request.js packages/config/eslint-plugin-hostyllo/rules/
cp hostyllo_fixes/bullmq/BULLMQ_DLQ_SPEC.md docs/

# From hostyllo-claude-agents.zip:
mkdir -p .claude/commands
cp hostyllo-claude-agents/.claude/commands/security.md .claude/commands/
cp hostyllo-claude-agents/.claude/commands/architect.md .claude/commands/
cp hostyllo-claude-agents/.claude/commands/db.md .claude/commands/

# Verify both critical files work:
pnpm run lint                                                # ESLint plugin must load cleanly
pnpm vitest run packages/db/src/__tests__/paymentService.test.ts  # All 14 must pass

git add .
git commit -m "chore: migrate production-ready files from ZIP archives to monorepo"
echo "File migration complete. Phase 0 is done."
```

**End of pre-work week. If `verify-pitr.sh` returned exit 0 AND all 14 payment tests pass, you're ready for Phase 1.**

---


---

## PHASE 0 — WEEK 1 — EXACT STEPS (Day-by-Day Detail)

> *This section from Set A v13 Beginner Guide — more granular than Stage 1 above. Follow Stage 1 for the framing; follow this for the exact account creation steps, PITR verification, and env var setup.*


**Day 1 — Service Accounts (2–3 hours)**

```
Step 1: Create Railway account (railway.app)
  → Upgrade to Pro plan immediately
  → Create new project named "hostyllo-api"
  → Note project URL

Step 2: Create Supabase account (supabase.com)
  → Create new project: "hostyllo-db", region: ap-south-1 (Mumbai)
  → Upgrade to Pro plan IMMEDIATELY — free tier FORBIDDEN
  → Go to Project Settings → Backups → Enable PITR, set 7-day retention
  → Run scripts/verify-pitr.sh — must exit 0 before any other step
  → Screenshot the result and save it as proof

Step 3: Create Upstash account (upstash.com)
  → Create Redis database
  → Copy the connection URL — verify it starts with "rediss://" (with 2 s's — TLS)
  → If it starts with "redis://" — find the TLS option and enable it
  → Plain "redis://" in production = security violation

Step 4: Apply for WhatsApp Business API via 360dialog
  → This takes 4–8 weeks to approve
  → Apply on Day 1 so you're not waiting in Phase 3
  → URL: https://www.360dialog.com/whatsapp-business-api
  → You can build everything without this — it's the SMS/copy-paste fallback until approved
```

**Day 2 — Secrets and Keys (1–2 hours)**

```
Step 5: Generate JWT RS256 keypair
  openssl genrsa -out private.pem 2048
  openssl rsa -in private.pem -pubout -out public.pem

  Add to Railway (backend): JWT_PRIVATE_KEY = contents of private.pem
  Add to Railway + Vercel (frontend): JWT_PUBLIC_KEY = contents of public.pem
  Delete both .pem files from disk after adding to Railway

Step 6: Generate AES-256 encryption key
  openssl rand -hex 32
  → Copy the output → add to Railway as ENCRYPTION_KEY
  → This encrypts CNIC and TOTP secrets
  → If you lose this key, all CNIC data is permanently unreadable
  → Save a backup in a password manager (1Password / Bitwarden)

Step 7: Set up all environment variables
  → See PRD Section 22 for complete list
  → Add ALL to Railway (backend) and relevant ones to Vercel (frontend)
  → Verify with: git log -p | grep -iE "key|secret|password" → must return empty
```

**Day 3 — Vercel + GitHub (1–2 hours)**

```
Step 8: Create GitHub repository
  → Name: hostyllo (or hostyllo-saas)
  → Private repository
  → Enable branch protection on "main":
    → Settings → Branches → Add rule for "main"
    → Check: "Require a pull request before merging"
    → Check: "Require status checks to pass before merging"
    → This means: no direct pushes to main, ever

Step 9: Create Vercel projects
  → vercel.com → Import from GitHub
  → Project 1: "hostyllo-web" → custom domain: app.hostyllo.app
  → Project 2: "hostyllo-admin" → custom domain: admin.hostyllo.app
  → Both connected to your GitHub repo
  → Add JWT_PUBLIC_KEY and other frontend env vars to Vercel

Step 10: Set up Cloudflare
  → cloudflare.com → Add site: hostyllo.app
  → Update nameservers at your domain registrar
  → Enable: WAF (free tier is enough for Phase 0–1)
  → This protects your app from DDoS and common attacks
```

**Day 4 — Monitoring (1 hour)**

```
Step 11: Set up Sentry
  → sentry.io → Create project: hostyllo-api (Node.js)
  → Copy SENTRY_DSN → add to Railway
  → Configure PII filter to block CNIC/keys from appearing in logs:
    Before initialising Sentry: Sentry.init({ beforeSend: (event) => {
      // strip any property matching SECRET|KEY|PASSWORD|TOKEN|CNIC
    }})
  → Throw a deliberate test error → verify it appears in Sentry dashboard

Step 12: Set up Uptime Robot
  → uptimerobot.com → Add Monitor → HTTP(s)
  → URL: https://api.hostyllo.app/health
  → Alert: SMS to your phone number
  → Test the alert fires correctly
```

**Day 5 — CI Pipeline (2–3 hours)**

```
Step 13: Set up GitHub Actions CI
  → Copy ci.yml from hostyllo_fixes/infra/ci.yml
  → Pipeline: lint → unit-tests → infra-gates → deploy
  → infra-gates checks: PITR active, Supabase Pro, RLS on all tables
  → Trigger a run on an empty repo → verify green

Step 14: Monorepo scaffold
  → Initialize pnpm workspace
  → Create apps/api/, apps/web/, packages/db/, packages/config/
  → Copy ESLint plugins from hostyllo_fixes/eslint/ into packages/config/
  → These two rules go live BEFORE any application code
```

**Phase 0 Done Checklist:**

```
⬜ Railway Pro — billing active
⬜ Supabase Pro — NEVER free tier
⬜ PITR enabled — verify-pitr.sh exits 0 — LOGGED WITH TIMESTAMP
⬜ Redis URL starts with rediss:// (TLS)
⬜ Both Vercel projects configured with custom domains
⬜ GitHub repo with branch protection on main
⬜ ALL env vars in Railway + Vercel — ZERO in code
⬜ Sentry — test event confirmed
⬜ Uptime Robot — SMS alert confirmed
⬜ CI pipeline — green run on GitHub Actions
⬜ 360dialog WhatsApp API — applied (even if not yet approved)
```

**If any item above is not checked, you are still in Phase 0. Do not write any application code.**

---


---

## PHASE 1 — MONTHS 1–4 — EXACT BUILD ORDER

> *From Set A v13 Beginner Guide — exact weekly sequencing for the API foundation.*


**The most important rule of Phase 1:** Build in this exact order. Every step depends on the previous.

### BLOCK 1 — Do First (Before Any Routes)

```
Task 1.1: ESLint security rules
  Files: packages/config/eslint-plugin-hostyllo/rules/
    → require-with-tenant.js (from hostyllo_fixes/eslint/)
    → no-hostel-id-from-request.js (from hostyllo_fixes/eslint/)
  Why first: These rules enforce the two most critical security properties.
             If they're not active, code review cannot catch violations.
  Verify: Write a test route that violates both rules → CI must fail

Task 1.2: withTenant() implementation
  File: packages/db/src/withTenant.ts
  Reference: PRD Section 8.3 — copy the exact pattern
  Critical: SET LOCAL must be inside BEGIN/COMMIT — never outside a transaction
  Verify: Write a test that shows SET LOCAL outside BEGIN → data bleeds to next query

Task 1.3: Database migrations (run in order)
  File: migrations/001_core.sql    → hostels, users, students, rooms, beds
  File: migrations/002_finance.sql → payments, payment_extra_charges, expenses, transfers, fines
  File: migrations/003_ops.sql    → cancellations, room_shifts, maintenance, complaints, checkin_log, notices
  File: migrations/004_system.sql → audit_log, subscriptions, receipt_counter, dlq_jobs, api_keys
  Verify: SELECT tablename FROM pg_tables WHERE rowsecurity=false → must return 0 rows

Task 1.4: Payment formula + 14 unit tests
  File: packages/db/src/paymentService.ts — port calculateUnpaid() verbatim from Electron app.js
  File: packages/db/__tests__/paymentService.test.ts — copy from hostyllo_fixes/tests/
  Verify: vitest run → 14/14 passing
  Gate: Payment routes do NOT start until all 14 tests pass in CI
```

### BLOCK 2 — Authentication (Week 2)

```
Task 1.5: JWT + auth middleware
  → JWT RS256 verification middleware (algorithms: ['RS256'] ONLY)
  → httpOnly refresh token cookie
  → jti blocklist in Redis
  → Role fetched from DB (never from JWT payload)
  → Per-warden flags from DB (can_delete, can_settings, can_edit)
  
Task 1.6: Auth endpoints (6 endpoints)
  → POST /auth/login
  → POST /auth/refresh
  → POST /auth/logout
  → POST /auth/reset-password
  → POST /auth/totp/setup
  → POST /auth/totp/verify
  
After each: cross-tenant isolation test
```

### BLOCK 3 — Core Data (Weeks 2–3)

```
Task 1.7: Students (7 endpoints)
  → CNIC: encrypt on create, mask in ALL responses, reveal = audit log
  → Auto-format: XXXXX-XXXXXXX-X (fmtCnic verbatim)
  → Photo: MIME + magic bytes check, max 2MB, resize 200×200
  → CSV import: strip = + - @ from every cell before insert
  → Search: pg_trgm GIN index, < 200ms target

Task 1.8: Rooms + Beds (6 endpoints)
  → Bed-level granularity
  → Prevent overbooking
  → Bulk fee update (3 modes)
  → Delete blocked if active occupants → RM_002 error

After each endpoint: Hostel A JWT → Hostel B data → must return 404
```

### BLOCK 4 — Finance (Weeks 3–4)

```
Task 1.9: Payments (8 endpoints)
  CRITICAL: 14 unit tests must pass before this block starts
  → calculateUnpaid() from packages/db/src/paymentService.ts
  → get_next_receipt_number() PostgreSQL function
  → Idempotency key: X-Idempotency-Key, Redis 24h
  → PDF receipt → BullMQ pdf-receipts queue (async, never blocks API)
  → Amount stored as NUMERIC(10,2) — never float

Task 1.10: Expenses (5 endpoints)
Task 1.11: Owner Transfers (4 endpoints)
Task 1.12: Fines (3 endpoints)
```

### BLOCK 5 — Infrastructure Routes (Weeks 5–6)

```
Task 1.13: Remaining operations
  → /cancellations (+ nightly Railway cron: auto-confirm expired)
  → /maintenance, /complaints, /checkin, /notices
  → /audit-log
  → /users (CRUD with per-warden flags)
  → /settings/hostel-info (minimal — 3 tabs only)
  → /dashboard/stats + /dashboard/alerts
  → GET /health

Task 1.14: All 7 BullMQ workers
  → pdf-receipts worker
  → whatsapp-blast worker (2s delay, 250/day counter in Redis)
  → whatsapp-receipt worker
  → billing-sync worker
  → data-export worker
  → auto-cancel worker
  → rent-generate worker
  → ALL workers: worker.on('failed') → moveToDLQ()
  → Verify DLQ fires by deliberately failing a job

Task 1.15: Sentry + Pino structured logging
  → Every route logs: { timestamp, level, requestId, hostelId, userId, action, duration_ms }
  → CNIC/passwords/tokens NEVER in logs (Sentry PII filter active)
```

### Phase 1 Final Gate

Before touching Phase 2, check every item in Section 00.1:

```
⬜ All 28 tables with RLS enabled
⬜ verify-pitr.sh exits 0 — logged with timestamp
⬜ All 14 payment tests pass in CI
⬜ Cross-tenant isolation on every endpoint
⬜ hostyllo/require-with-tenant ESLint rule blocking in CI
⬜ /health returns db:ok and redis:ok
⬜ bcrypt rounds ≥ 12 verified
⬜ CNIC encrypted — direct DB query confirms no plaintext
⬜ Soft-delete verified on all list endpoints
⬜ get_next_receipt_number() concurrency tested
⬜ BullMQ DLQ on all 7 queues
⬜ Sentry receiving events
⬜ No secrets in git
```

**If any box is unchecked, Phase 1 is not done. Do not start Phase 2.**

---


---

## STAGE 2: PHASE 1 — CLOUD API (Months 1–4)

> **Your goal this stage:** Backend API that a warden can use to manage a hostel.
> You are NOT building a UI yet. You are not building onboarding yet. Just the API.

### Week 1–2: Database Setup

**The Golden Rule:** Every table you create must have RLS enabled immediately. Never create a table without RLS.

```bash
# Open your Claude Code session. Your first message:
"Read docs/05_CLAUDE_MD_v11.md in full. 
Then read docs/01_MASTER_PRD_v14.md Section 17 (Database Schema).
Build: Migration 001 — hostels and users tables with RLS.
Verify: SELECT tablename FROM pg_tables WHERE rowsecurity=false; must return 0 rows."
```

Build the tables in this exact order (each migration = one commit):
1. `hostels` + `users` → commit
2. `students` + `rooms` + `beds` → commit
3. `payments` + `payment_extra_charges` + `expenses` + `owner_transfers` + `fines` → commit
4. `cancellations` + `room_shifts` + `maintenance_requests` + `complaints` + `checkin_log` + `notices` → commit
5. `room_inspections` + `bill_splits` → commit
6. System tables: `subscriptions` + `audit_log` + `receipt_counter` + `warden_shift_log` + `dlq_jobs` → commit
7. Product tables: `feedback` + `nps_responses` + `onboarding_events` + `referral_payouts` + `api_keys` → commit

After all migrations: Run `verify-pitr.sh` again. Run RLS check again.

### Week 3–4: Core Package Setup

**Build `packages/db` first — before any route:**

```bash
# Claude Code message:
"Read tasks/lessons.md. Read docs/05_CLAUDE_MD_v11.md.
Build packages/db:
1. withTenant.ts — the exact implementation from the CLAUDE.md
2. paymentService.ts — calculateUnpaid() ported verbatim from Electron
3. paymentService.test.ts — all 14 test cases from PRD Section 09
4. formatters.ts — fmtCnic() and fmtPhone() ported verbatim
Run the tests. All 14 must pass. Show me the output."
```

**Do not build any route until these 14 tests pass.**

### Week 5–6: Authentication

```bash
# Claude Code message:
"Read tasks/lessons.md. Read docs/05_CLAUDE_MD_v11.md Critical Rules.
Build authentication:
- POST /api/v1/auth/login (bcrypt 12 rounds, RS256, TOTP check)
- POST /api/v1/auth/refresh (rolling rotation, jti Redis blocklist)
- POST /api/v1/auth/logout
- JWT middleware (algorithms: ['RS256'], jti check, role from DB — NOT from JWT payload)
- Rate limit middleware (10 attempts/15min/IP via Redis rl:login:{ip})
- Security headers on every response

After each endpoint: cross-tenant isolation test must pass."
```

### Week 7–10: Core CRUD Modules

**For each module, use this Claude Code prompt pattern:**

```bash
"Read tasks/lessons.md. Current build state: [describe what exists].
Build: [module name] endpoints. 
Requirements: PRD Section [X] — [module section].
After each endpoint: 
  1. Cross-tenant isolation test (Hostel A JWT → Hostel B data → 404)
  2. git commit -m 'feat: [endpoint name]'
Do not proceed to the next endpoint until the isolation test passes."
```

**Module build order:**
1. Students (7 endpoints) — most important daily operation
2. Rooms + Beds (6 endpoints)
3. Payments (8 endpoints) — PORT calculateUnpaid() verbatim, NEVER reinvent
4. Expenses + Transfers + Fines (finance group)
5. Cancellations + Maintenance + Complaints (operations group)
6. Check-In, Notices, Dashboard stats, Users, Health

### Week 11–12: BullMQ + PDF Receipts

```bash
"Build BullMQ infrastructure:
1. All 7 queue definitions
2. pdf-receipts worker — puppeteer → PDF → Supabase Storage
3. Every worker MUST have worker.on('failed') → moveToDLQ()
4. moveToDLQ() utility writing to dlq_jobs table
5. Verify: manually trigger a DLQ by making a job fail 3 times — it must appear in dlq_jobs"
```

### Phase 1 Exit: Run the Full Checklist

Go to `docs/01_MASTER_PRD_v14.md` Section 00.

Every item in the "Phase 1 Definition of Done" checklist must be checked. No partial credit. Every item checked = Phase 2 begins. Any item unchecked = fix it first.

---

## STAGE 3: PHASE 2 — WEB FRONTEND (Months 4–7)

> **Your goal:** A warden can manage their hostel entirely in the browser.
> You are building the UI that calls the API you built in Phase 1.

### Getting Started with the Frontend

```bash
# Claude Code message for first frontend session:
"Read docs/05_CLAUDE_MD_v11.md. Read docs/01_MASTER_PRD_v14.md Section 41 (Design System).
Set up the Next.js 14 App Router shell in apps/web:
1. Install Tailwind CSS + shadcn/ui + Framer Motion
2. Load fonts: Figtree, DM Mono (from Google Fonts), Noto Nastaliq Urdu
3. Implement all design tokens from Section 41 as CSS variables
4. Build the app shell: sidebar (260px desktop, icon rail on collapse) + top header
5. Add mobile bottom tab bar
Do NOT build any module screens yet. Just the shell."
```

### Mobile-First Screen Build Order

Every screen: design at 390px first. Then expand to desktop. Never the other way.

1. **Login screen** — mobile-optimized form, no decorative elements that slow load
2. **Dashboard** — 5 KPI cards (animated count-up), alert banners, occupancy grid, quick actions
3. **Students list + Add student flow** — typeahead search, 3-step add flow
4. **Payment recording** — mobile-optimized 3-step flow (Student Picker → Details → Confirm)
5. **Rooms list + occupancy grid** — gold/green/grey beds
6. **Expenses list + add modal**
7. All remaining modules (follow the feature map)

### UI Quality Checklist (After Every Screen)

Before moving to the next screen:
- [ ] Works on 390px mobile (open Chrome DevTools, iPhone 13 size)
- [ ] No spinners — only skeleton shimmers while loading
- [ ] Empty state has illustration + English + Urdu + CTA button
- [ ] All tappable elements ≥ 44×44px
- [ ] Numbers use Pakistani lakh format (1,00,000 not 100,000)
- [ ] Dark mode works (toggle in header)

---

## STAGE 4: GET YOUR FIRST PAYING CLIENT (Ongoing from Phase 1)

> **This stage runs in parallel with all technical stages.**
> Do not wait for Phase 3 to start selling. Start this in Month 1.

### Month 1 — Call Your Electron Clients

1. List all 50+ Electron hostel clients you know personally
2. Call the top 5 (the ones who are most active and trust you most)
3. Your script:
   > "Bhai, I'm building the web version. Cloud backup, phone access, WhatsApp reminders. I want 3 beta testers to try it free and give feedback. Are you interested?"
4. Target: 3 yeses before Phase 2 starts

### Month 2 — Beta Onboarding (Manual)

When your API is working (Phase 1 done):
1. Sign up your first beta client manually (create their hostel in the DB directly)
2. Walk them through adding their first student together (screen share via Zoom/WhatsApp call)
3. Help them record their first payment and send a WhatsApp receipt (copy-paste method)
4. Ask: "Would you pay PKR 2,999/month for this?" The answer tells you everything.

### Handling Common Objections

| Objection | Your Response |
|-----------|--------------|
| "The desktop app works fine, why pay monthly?" | "The SaaS has cloud backup (your data survives if the laptop dies), web access from your phone, and automated WhatsApp rent reminders. The desktop app has none of these." |
| "Monthly fee is expensive." | "One missed payment dispute with no audit trail costs more than 3 months of the Starter plan. With HOSTYLLO, every payment is recorded and receipted permanently." |
| "I don't trust the internet with my student data." | "Student CNIC data is AES-256 encrypted — not even I can read it without the encryption key. And you can export all your data at any time from Settings — your data is never held hostage." |
| "What if you shut down?" | "Before any account is deleted, we automatically email you a complete export of all your data. You always own your data." |

### What NOT to Do

- Do NOT build features requested by non-paying potential clients
- Do NOT launch paid ads before 5 paying clients are live for 60+ days
- Do NOT demo features that are not live in production
- Do NOT promise WhatsApp automation until 360dialog is approved and tested

### Month 2–3 — Client Onboarding Checklist (Per Client)

Use this checklist every time you onboard a real client. Nothing is skipped.

**Pre-onboarding (before you create their account):**
- [ ] WhatsApp group created with hostel owner (you + them)
- [ ] Client's full name, hostel name, city, and WhatsApp number collected
- [ ] DPA template sent and signed (`docs/legal/DPA_template.md`) — get written confirmation via WhatsApp if PDF is slow
- [ ] Client informed: "CNIC data is encrypted — even I cannot read it"
- [ ] Client informed: data residency is Mumbai (cloud servers in India)

**Technical setup:**
- [ ] Hostel record created in DB (Super Admin panel → Create Tenant or manual INSERT)
- [ ] Owner account created with their email — temporary password set
- [ ] Temporary password sent via WhatsApp only (not email, not SMS — WhatsApp is auditable in your group)
- [ ] Client changes password on first login — confirmed

**Data migration:**
- [ ] Client given CSV import template (download from Settings → Data Management)
- [ ] Client fills in their student list — you review it before import
- [ ] Check for: missing CNIC, wrong phone format, duplicate names
- [ ] Import done → student count confirmed matches their own records

**Training session (screen share — 30 minutes):**
- [ ] Walk through: Add a student (demo with fake data first)
- [ ] Walk through: Record a payment → WhatsApp receipt (copy-paste method)
- [ ] Walk through: Defaulters list → bulk reminder
- [ ] Walk through: Monthly report → PDF export
- [ ] Client asks questions — you answer

**Confirmation:**
- [ ] Client confirms: "Main ye khud kar sakta hoon" ("I can do this on my own")
- [ ] Client has your WhatsApp number saved for support
- [ ] Client added to your support WhatsApp group
- [ ] First payment method agreed: bank transfer / JazzCash / EasyPaisa

**Post-onboarding:**
- [ ] 48-hour check-in: "Koi problem toh nahi?" ("Any problems?")
- [ ] 7-day check-in: Are they actually using it? Check last_activity in Super Admin.
- [ ] 30-day check-in: NPS question — "On a scale of 0-10, how likely are you to recommend HOSTYLLO?"

---

## STAGE 5: PHASE 3 — ONBOARDING + SUPER ADMIN (Months 7–10)

> **Your goal:** New clients can sign up without calling you.
> This unlocks self-serve growth.

### Build Order

1. **Onboarding wizard** — all 7 steps with event tracking
2. **Super Admin panel** — you need to see what's happening with clients
3. **Landing page** — hostyllo.app with pricing, Pakistani-specific trust signals
4. **AI Tier 1 features** — risk scoring, maintenance pattern detection (3-4 days work)
5. **NPS survey** — start collecting satisfaction data from Day 1

### Going Live with Self-Serve

Before enabling self-serve signups:
1. Privacy Policy live at hostyllo.app/privacy ← Legal requirement
2. Terms of Service live at hostyllo.app/terms ← Legal requirement
3. Onboarding wizard tested end-to-end with a non-technical person (ask a family member)
4. WhatsApp step in wizard: fallback to SMS → copy-paste → "skip" confirmed working

---

## STAGE 6: PHASE 4 — BILLING AUTOMATION (Months 10–13)

> **Your goal:** Stop manually collecting money. Every client pays automatically.

### Before You Build Paymob

1. Confirm Paymob merchant account is approved (you applied in Month 1)
2. Read Paymob's webhook documentation carefully
3. Test the full payment flow in Paymob sandbox first (they provide test JazzCash numbers)

### Most Critical Billing Tasks

```bash
# Most critical security task in billing:
# The Paymob webhook handler MUST verify HMAC-SHA512 before processing ANYTHING.
# A fake webhook = fake subscription activation = free access = revenue theft.

# Test: Send a webhook with wrong HMAC → must return 400 and log the attempt
# Test: Send a webhook with correct HMAC → must process normally
# Never trust a payment webhook without HMAC verification.
```

---

## STAGE 7: PHASE 5 — WHATSAPP + OFFLINE + SCALE (Months 13–18)

> **Your goal:** Automated communications live. System handles real scale.

### The Offline Sync Warning

The offline sync engine (SQLite CRDT) is the most complex piece of the entire system. Here is how to not destroy yourself building it:

1. Build it in `packages/sync/` in COMPLETE isolation — do not connect to any UI yet
2. Write 10 integration tests before connecting to anything
3. Tests must cover: normal sync, conflict (same record edited on two devices), large batch (500 rows), connection drop mid-sync
4. Only after all 10 tests pass: connect to the UI
5. Never ship an untested sync engine

```bash
# Load test before Phase 5 launch — non-negotiable:
k6 run --vus 500 --duration 60s scripts/load-test.js
# p95 latency must be < 200ms. If it fails, do not launch Phase 5.

# OWASP scan before Phase 5 launch — non-negotiable:
docker run -t owasp/zap2docker-stable zap-baseline.py -t https://app.hostyllo.app
# All critical and high findings must be resolved. Do not launch Phase 5 with open findings.
```

---


## MONTHLY MAINTENANCE RITUALS

**Do these on the 1st of every month:**

```bash
# 1. PITR verification (5 minutes)
./scripts/verify-pitr.sh
# Log the output with timestamp in tasks/lessons.md

# 2. Infrastructure cost review (10 minutes)
# Open Railway, Supabase, Upstash dashboards
# Record current monthly spend
# Compare to budget from PRD Section 33

# 3. Delete orphaned Railway environments (5 minutes)
# Any preview environment not used in 7+ days: delete it
# Orphaned environments cost money

# 4. Review tasks/lessons.md (15 minutes)
# Read all lessons accumulated since last review
# Are any being violated? Fix them.
```

**Do on 1st of every quarter:**
```bash
# DR drill (2 hours)
# 1. Pick a past timestamp (e.g., 7 days ago at 14:00)
# 2. Request PITR restore to staging
# 3. Verify row counts match expected
# 4. Log result in tasks/lessons.md: "DR drill [date]: PASSED/FAILED [notes]"
```

---

## WHEN SOMETHING GOES WRONG — FULL INCIDENT RUNBOOK

### Incident Severity Quick-Reference

| Level | Examples | Your Response Time |
|-------|---------|-------------------|
| P0 | Data appears lost · Payment formula wrong · Full outage · Security breach | **Immediate — drop everything** |
| P1 | Login broken · Receipts not generating · All payments showing wrong amount | **Within 1 hour** |
| P2 | One module broken but workaround exists · Slow performance | **Same business day** |

---

### P0: Full Outage (API returning 500 or not responding)

```bash
# STEP 1 — Diagnose (< 5 minutes)
railway logs --tail --project hostyllo          # Check for crash errors
# Also check: app.hostyllo.app → should show error or load
# Also check: Uptime Robot status page → is this alerting?

# STEP 2 — Quick restarts (try in order)
railway restart hostyllo-api                    # Restart the API service
# Wait 30 seconds. Check /health endpoint.
# If still down:
railway scale --replicas=0 hostyllo-api && sleep 10 && railway scale --replicas=2 hostyllo-api

# STEP 3 — If it's a DB connection issue
# Check Supabase status: status.supabase.com
# Check PgBouncer pool: Supabase → Database → Connection Pooling → check pool size
# If pool exhausted: railway scale --replicas=1 temporarily to reduce connections

# STEP 4 — Communicate (within 15 minutes of discovering the outage)
# WhatsApp to affected clients:
# "HOSTYLLO mein abhi kuch masla aa gaya hai. Hum theek kar rahe hain.
#  30 minute mein update denge." (We have an issue, fixing it, update in 30 min.)

# STEP 5 — Fix and deploy
git stash                                       # Clean working tree
git checkout -b hotfix/[describe-issue]
# Make the minimal fix
pnpm vitest run packages/db/src/__tests__/paymentService.test.ts  # Must pass
git push && merge to main via PR               # CI must pass
# Vercel and Railway auto-deploy on main merge

# STEP 6 — Post-mortem (before sleeping)
echo "INCIDENT $(date): [what happened] → [root cause] → [fix] → [prevention]" >> tasks/lessons.md
```

---

### P0: Payment Formula Producing Wrong Amounts

```bash
# This is the most serious non-security bug. Wrong amounts = financial harm to clients.

# STEP 1 — Confirm the bug
# Get the specific payment ID from the client
# Compare: calculateUnpaid() output vs what the DB stored vs what the receipt shows

# STEP 2 — DO NOT attempt to fix payments in production DB directly
# Never UPDATE payments records — audit_log integrity requires INSERT-only

# STEP 3 — Run payment tests immediately
pnpm vitest run packages/db/src/__tests__/paymentService.test.ts
# If any test fails → you have identified a regression. Fix calculateUnpaid() ONLY.
# If all tests pass → the bug is likely in the UI calculation or a DB rounding issue

# STEP 4 — Client communication
# "Aap ki payment mein calculation mein masla tha. Hum check kar rahe hain.
#  Koi payment delete nahi hogi — sab record safe hai." (Records are safe, investigating.)

# STEP 5 — Fix
# If calculateUnpaid() had a regression: fix → all 14 tests pass → deploy
# If it's a display bug only: fix the UI → deploy
# If individual payment records are wrong: create a void + re-record workflow (NEVER UPDATE)
```

---

### P0: "Supabase is Down" / Database Unreachable

```bash
# STEP 1 — Check status.supabase.com — is it a platform incident?
# If yes: nothing to do except communicate to clients and wait.
# Post in client WhatsApp: "Cloud database provider mein masla hai.
#  Jab theek hoga, apne aap kaam shuru ho jaye ga." (Will resume automatically.)

# STEP 2 — If Supabase shows green but your DB is not responding
# Check: Supabase → Project → Pause status (free tier pauses after 1 week inactive)
# If paused: click "Restore project" (takes 2-3 minutes)
# PREVENT: Supabase Pro plan does not pause. You must be on Pro. Check billing.

# STEP 3 — If it's a connection pool exhaustion
# Supabase → Database → Connection pooling → check active connections vs limit
# Railway: scale API replicas down to 1 temporarily
# Each replica uses max 25 connections. 5 replicas = 125 connections.
# PgBouncer transaction mode should handle this — if not, check pool config.
```

---

### P1: Login Broken for All Users

```bash
# Most likely causes: JWT key mismatch, Redis down, bcrypt version mismatch

# Check Redis first (most common cause of auth failures)
redis-cli -u $REDIS_URL ping    # Must return PONG
# If Redis is unreachable: rate limiting and jti blocklist are unavailable
# Fallback: Railway → Upstash dashboard → check status

# Check JWT keys
# Railway env vars: confirm JWT_PRIVATE_KEY and JWT_PUBLIC_KEY are set and not empty
# Common mistake: env var has extra whitespace or newline at end — regenerate and re-paste

# Check Sentry for the exact error message — it will tell you the exact failure point
```

---

### P1: "Client Says Their Receipt is Wrong"

```bash
# STEP 1 — Get exact details: student name, month, receipt number
# STEP 2 — Look up the payment in DB (Super Admin → Tenant → Payments)
# STEP 3 — Run calculateUnpaid() manually with the stored values:
node -e "
const { calculateUnpaid } = require('./packages/db/src/paymentService');
const result = calculateUnpaid(RENT, ADM_FEE, [EXTRAS], CONCESSION, PAID);
console.log(result);
"
# STEP 4 — Compare result to what the receipt shows
# If mismatch → receipt HTML template has a bug → fix buildReceiptHTML(), not the DB records
# If match → the warden entered the wrong amount originally → void + re-record workflow
```

---

### P2: App is Slow (p95 > 500ms)

```bash
# Check Railway metrics: CPU, memory, replica count
railway metrics hostyllo-api

# Check if a specific endpoint is slow:
# Sentry → Performance → slowest transactions

# Check Supabase slow queries:
# Supabase → Database → Query Performance → sort by mean execution time

# Most common slow queries and fixes:
# - students search slow: check GIN index exists on students(name, city, cnic_encrypted)
# - dashboard slow: ensure dashboard_stats runs as a single aggregation query, not 5 separate SELECTs
# - payments list slow: add index on payments(hostel_id, month, deleted_at)

# Quick wins:
railway scale --replicas=3 hostyllo-api         # Add replicas if CPU > 70%
```

---

### When Claude Code Goes Wrong

```
1. STOP — do not continue generating in the wrong direction
2. Check tasks/lessons.md — has this exact pattern failed before?
3. git diff — see exactly what changed in this session
4. git stash — undo everything from this session if needed
5. Read the specific PRD section (Section number + requirement ID) for what you're building
6. Start fresh prompt: reference the exact PRD section + rule numbers from CLAUDE.md
7. After fixing: update tasks/lessons.md with what went wrong and the new rule
```

---

## YOUR NORTH STAR METRICS

Check these weekly. Not daily (too distracting). Not monthly (too slow to react).

| Metric | Target | Where to Find It |
|--------|--------|-----------------|
| Paying clients | 5 before Month 6 | Manual count |
| Weekly active wardens | > 50% of clients | Super Admin panel |
| P0 incidents | 0 per month | Sentry + client WhatsApp groups |
| Payment formula test pass rate | 100% always | CI dashboard |
| API p95 latency | < 200ms | Railway metrics |

---

## THE ONE RULE TO RULE THEM ALL

If you feel overwhelmed. If you're not sure what to build next. If scope is creeping. Come back to this:

> "What is the single thing that, if I build it today, gets me one step closer to 5 paying clients?"

Build that. Ship it. Move on.

---

*HOSTYLLO Beginner Guide v14.0 · Zeerak Hostix · May 2026 · Confidential*

---

## DAILY WORK HABITS

### Before Every Work Session (5 minutes)

```
1. Open docs/tasks/lessons.md — read all lessons relevant to today's work
2. Write today's plan in docs/tasks/todo.md:
   - What phase are you in?
   - What is the ONE thing you're building today?
   - What is the verification step?
3. Check: have you run verify-pitr.sh this month?
4. Check: is Phase 1 DoD complete? If not, you're still in Phase 1.
```

### During Work Session

```
→ Complete ONE task at a time
→ Write cross-tenant isolation test BEFORE marking endpoint done
→ Commit after every working endpoint: git commit -m "feat: POST /students — CNIC encrypt, photo validate"
→ If stuck > 45 min on same issue: document it in todo.md and move to next task
→ Never commit broken tests to main
```

### After Every Work Session (5 minutes)

```
1. Update docs/tasks/todo.md: mark completed items, note blockers
2. Update docs/05_BUILD_STATE.md: mark tasks done
3. Add to docs/tasks/lessons.md: any correction you received or mistake you made
4. git push to your feature branch
5. One sentence: "What do I build next session?"
```

### Monthly Checks (1st of Every Month)

```
□ Run verify-pitr.sh — log result with date
□ Review infrastructure costs — update PRD Section 28 if rates changed
□ Check: any Dependabot security PRs pending? Review and merge.
□ Check: DLQ jobs in Super Admin — any unresolved?
□ Check: Sentry — any recurring errors?
□ If Phase 4+: run DR drill (restore staging from PITR, verify row counts)
```

---

## WHEN THINGS GO WRONG

### "The tests are failing"

```
1. Run the specific failing test in isolation: vitest run --reporter=verbose paymentService
2. Read the error message exactly — do not guess what it means
3. Check docs/tasks/lessons.md for the same pattern
4. If it's a payment formula test: go to PRD Section 7.4, re-read the exact formula
5. If stuck > 3 attempts on same test: write it in lessons.md and escalate to /debug command
```

### "The cross-tenant test is failing"

```
1. This is a CRITICAL security issue — do not dismiss it
2. Check: is withTenant() wrapping the query?
3. Check: is SET LOCAL inside BEGIN/COMMIT? (not outside)
4. Check: is hostel_id coming from JWT (req.hostelId), never from body?
5. Do not deploy until this test passes
```

### "A client reports data looks wrong"

```
Severity P0 — drop everything
1. Immediately check: is calculateUnpaid() returning correct values? Run the 14 tests.
2. Check: is the right hostel_id being used? (IDOR risk)
3. Check audit_log for the affected entity to see what changed
4. Respond to client's WhatsApp group within 1 hour with: "We are investigating, here is what we know so far"
5. Never speculate in the client's WhatsApp group — only confirmed facts
```

### "Railway is down"

```
1. Check Railway status page: status.railway.app
2. Check Sentry for error spike
3. Post in client WhatsApp groups: "We are aware of a service issue. Working to restore."
4. Check if fallback is needed (Vercel frontend will show error state — that's OK)
5. If DB is inaccessible, check Supabase status: status.supabase.com
```

### "I'm not sure what to build next"

```
Answer: Re-read this Beginner Guide from your current phase.
The answer is always the next unchecked item in the current phase's build order.
If you're uncertain whether Phase 1 is done: it's not. Check the Phase 1 DoD.
```

---

## FINANCIAL CHECKPOINTS

### Before Spending Any Money on Marketing
- Phase 1 DoD: 100% complete ✓
- At least 1 beta client using the product ✓
- At least 1 client has paid (even manually) ✓

### Before Hiring Anyone
- Trigger: MRR > PKR 150,000/mo for 2 consecutive months
- First hire: Full-Stack Developer
- Second hire: Support/Customer Success
- Never hire before cash flow is positive for 2 months

### Subscription Pricing (Do Not Change Without Strong Evidence)

| Plan | Price | When to Pitch |
|------|-------|---------------|
| Starter | PKR 2,999/mo | Small hostels (≤ 50 students, 1 branch) |
| Pro | PKR 6,999/mo | Medium hostels (50–200 students) or 2–3 branches |
| Enterprise | PKR 14,999/mo | Chains (4+ branches) or very large hostels |

The annual discount (20%) is a strong closing tool. Use it when client hesitates on monthly price.

---

## SUPPORT OPERATIONS

### Every Client Gets a WhatsApp Group
Format: "HOSTYLLO — [Hostel Name]"
Members: Zeerak + hostel owner + head warden

### Response Time Commitments
- P0 (data appears wrong, can't log in): **4 hours, 8am–10pm PKT every day**
- P1 (feature broken, workaround exists): **Same business day**
- P2 (UI issue, cosmetic): **Next release**

### What to Say in WhatsApp When Something Breaks
```
"We are aware of an issue with [feature]. We are working to fix it.
Current status: investigating.
We will update you in [time estimate].
A workaround is: [if one exists].
Thank you for your patience."
```

Then: fix it. Then: confirm fixed. Then: add lesson to lessons.md.

### What NEVER to Say to Clients
- "That feature is coming soon" (unless it's in the current phase)
- "That's a bug in the other system" (own the problem)
- "I'll fix it when I get a chance" (give a time estimate)
- "Can you try clearing your cache?" (only if you actually believe it's a cache issue)

---

## LEGAL CHECKLIST (PDPA 2023 — Pakistan)

Before any paying client data enters the system:

```
⬜ Privacy Policy live at hostyllo.app/privacy
    Must state: what PII collected, how encrypted, retention periods,
                right to export, right to request deletion
                
⬜ Terms of Service live at hostyllo.app/terms
    Must include: ToS acceptance logged with timestamp + IP during onboarding
    
⬜ Data Processing Agreement (DPA) template prepared
    HOSTYLLO = data processor (processes student data for the hostel)
    Hostel = data controller (controls their students' data)
    Sign DPA before any client uploads student PII
    
⬜ Impersonation disclosure in both Privacy Policy and Terms
    "HOSTYLLO support staff may access your account for support purposes.
    All such access is logged and auditable."
    
⬜ Data export: any client can get their full data within 48 hours, on request
⬜ Data deletion: when a client cancels, their PII is deleted within 30 days
```

---

## QUICK REFERENCE CARDS

### "What is the payment formula?"
```
totalDue = rent + admissionFee + sum(extraCharges) - concession
unpaid   = Math.max(0, totalDue - amountPaid)
status   = amountPaid >= totalDue ? 'paid' : amountPaid > 0 ? 'partial' : 'pending'
```
Port verbatim from Electron app.js. 14 unit tests validate it. Never change it without re-running all 14.

### "Where does hostel_id come from?"
```
ALWAYS: const hostelId = request.user.hostelId  // from JWT middleware
NEVER:  const hostelId = request.body.hostel_id  // IDOR vulnerability
NEVER:  const hostelId = request.params.hostel_id
NEVER:  const hostelId = request.query.hostel_id
```

### "How do I store money amounts?"
```
In PostgreSQL: NUMERIC(10,2) — never FLOAT
In JavaScript: string or BigInt — never number type for financial math
In API responses: string → "8000.00" — never number → 8000
```

### "What encryption do I use for CNIC?"
```
Algorithm: AES-256-GCM
Key: process.env.ENCRYPTION_KEY (32 bytes, never in code)
Store: cnic_encrypted column (TEXT, base64-encoded ciphertext + IV + tag)
Return: masked_cnic = "XXXXX-XXXXXXX-X" in ALL API responses
Reveal: only on explicit user action + audit_log entry
```

### "What do I check before every deploy?"
```
1. All 14 payment unit tests pass in CI
2. No secrets in git: git log -p | grep -iE "key|secret|password" → empty
3. CI infra-gates pass (PITR, RLS, Supabase Pro)
4. Cross-tenant test passes for new/modified endpoints
```

---

*HOSTYLLO Beginner Guide v13.0 · Zeerak Hostix · May 2026 · Confidential*
*This document is your daily operating manual. When lost, come back here.*

---

*HOSTYLLO Beginner Guide v15.0 · Zeerak Hostix · May 2026 · Confidential*
*Supersedes: Beginner Guide v14.0, v13.0, v11.0 and all prior versions.*
*Opening sections (business framing, pre-work) from Set B v14. Phase 0/1 granular steps from Set A v13. Daily habits, financial checkpoints, support ops, and legal from Set A v13.*
*This document is your daily operating manual. When lost, come back here.*
