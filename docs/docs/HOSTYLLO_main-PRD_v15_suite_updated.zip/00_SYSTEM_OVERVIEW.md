# HOSTYLLO — SYSTEM OVERVIEW
## Unified Intelligence Brief · v15.0 · May 2026
### Synthesized from: PRD v14, v13 gap-fill suite, all prior archives

| Field | Value |
|-------|-------|
| Document | System Overview — Single-Page Intelligence Brief |
| Synthesized By | System Architect of Record |
| Source Authority | Both v13 gap-fill suite (Set A) and v14 enterprise suite (Set B) — fully merged |
| PRD Authority | 01_MASTER_PRD_v15.md supersedes all prior versions |
| Build Status | Phase 0 — NOT STARTED (all tasks ⬜ TODO) |
| Classification | Confidential — Founder Only |

---

## 1. WHAT HOSTYLLO IS

HOSTYLLO is a **cloud-native, multi-tenant SaaS hostel management platform** for Pakistan-first with global expansion goals. It is not generic ERP. It is not admin software. It is the operational backbone of modern accommodation businesses — from a single boarding house in Peshawar to a 10-branch student housing chain in Karachi.

**Product DNA:** Every feature traces to a real, battle-tested Electron desktop application (DAMAM HMS / HOSTIX) currently live at 50+ Pakistani hostels. ~12,000 lines of JavaScript. 316 functions. 14 modules. Zero speculative features.

**Repositioned Vision:** "An AI-powered operational intelligence platform for modern accommodation businesses."

---

## 2. ALL UPLOADED FILES — AUDIT VERDICT

| File | Type | Authority Level | Key Contribution |
|------|------|----------------|-----------------|
| 01_MASTER_PRD_v15.md | PRD | **HIGHEST** — Current canonical PRD | 45 sections, all invariants, solo rules, budget, PDPA, enterprise architecture |
| files__9_.zip (Set A) | v13 gap-fill suite | HIGH — Authoritative for UX Design System, Blueprint, Feature Map FR-IDs | 7 files, 140KB |
| files__8_.zip (Set B enhanced) | v14+ enterprise suite | HIGH — Authoritative for CLAUDE.md workflow, Roadmap PKR tables, Beginner Guide framing | 9 files, 222KB |
| files__7_.zip (Set B original) | v14 enterprise suite | HIGH — Original v14 baseline | 9 files, 183KB |
| hostyllo_docs_v10.zip | Docs bundle | MEDIUM — Superseded | CLAUDE.md v10, Roadmap v10, Architecture v10 |
| HOSTYLLO_Enterprise_Analysis_Report.docx | Risk audit | HIGH | 34 security risks, 23 Electron gaps, 11 SaaS gaps |
| hostyllo_fixes.zip | Code artifacts | HIGH | ESLint rules, CI/CD yaml, PITR script, payment tests, BullMQ spec |
| hostyllo-claude-agents.zip | AI workflow | HIGH | CLAUDE.md v9, command palette |
| Cloudberry_PRD.docx / _1.docx | UNRELATED | NOT APPLICABLE | Different product entirely. Not integrated. |

**CRITICAL FINDING:** The two Cloudberry PRD files are for a completely different product (a developer platform for local-to-production parity). They are NOT integrated into this system.

---

## 3. KEY ARCHITECTURAL DECISIONS (LOCKED)

| Decision | Value | Why Locked |
|----------|-------|------------|
| Frontend | Next.js 14 App Router, Vercel | Serverless, zero-config CI, global CDN |
| Backend | Fastify 4, Node.js, Railway | Low-latency, schema validation built-in |
| Database | PostgreSQL via Supabase (Mumbai, ap-south-1) | PITR backup, RLS multi-tenancy, pg_trgm search |
| Cache/Queue | Redis via Upstash (serverless), BullMQ | rediss:// TLS, pay-as-you-go |
| Auth | JWT RS256 asymmetric, httpOnly refresh cookie | Algorithm confusion attack prevention |
| Multi-tenancy | PostgreSQL RLS + withTenant() pattern | SET LOCAL inside BEGIN/COMMIT — race condition eliminated |
| Offline (Phase 5) | SQLite Wasm (wa-sqlite, OPFS) | Browser-native, no install required |
| Billing (Phase 4) | Paymob — JazzCash/EasyPaisa | Only Pakistan-approved gateway with mobile money |
| WhatsApp (Phase 3) | 360dialog — Meta Business API | 250/day cap, 2s delay enforced |
| AI/Automation (Phase 7) | DEFERRED — MRR trigger + hire required | Solo founder cannot staff ML in 24 months |

---

## 4. CURRENT BUILD STATE

**Phase:** Phase 0 — Infrastructure Setup  
**Status:** NOT STARTED  
**Everything is ⬜ TODO**  
**First client data:** Blocked until `verify-pitr.sh` returns exit code 0

**Pre-work items that must happen before touching code:**
1. Enable Supabase PITR — 5 minutes
2. Apply for Meta WhatsApp Business API — NOW (4–8 week approval)
3. Apply for Paymob merchant account — NOW (1–3 business days)
4. Generate JWT RS256 keypair — `openssl genrsa -out private.pem 2048`
5. Create PWA manifest.json
6. Set up Sentry with PII filter

---

## 5. CRITICAL INVARIANTS (6 ABSOLUTE RULES — NEVER VIOLATE)

> These are the 6 rules that, if violated, result in either a security breach, data loss, or financial error. They are hardcoded into CI and ESLint.

```
INVARIANT-1: algorithms: ['RS256'] ONLY in jwtVerify() — HS256 = token forgery
INVARIANT-2: withTenant() wraps EVERY DB query — raw queries = cross-tenant data breach
INVARIANT-3: hostel_id from JWT ONLY — never from body/params/query = IDOR
INVARIANT-4: Payment amounts: NUMERIC(10,2) ONLY — FLOAT = accounting errors
INVARIANT-5: audit_log: INSERT ONLY — UPDATE/DELETE = tamper evidence destroyed
INVARIANT-6: Supabase PITR active before any client data — Free tier = production FORBIDDEN
```

---

## 6. WHAT DOCUMENTS THIS SUITE CONTAINS

| File | Purpose |
|------|---------| 
| 00_SYSTEM_OVERVIEW.md | This document — complete synthesis |
| 01_MASTER_PRD_v15.md | THE source of truth — v14 with v15 merge changelog |
| 02_PRODUCT_BLUEPRINT.md | Architecture, modules, system map, data flows (541-line Set A version + Set B middleware diagram) |
| 03_FEATURE_MAP.md | Unified feature inventory — FR-IDs from Set A + emoji priorities from Set B |
| 04_UX_DESIGN_SYSTEM.md | Full UX specification — resolves GAP-1 from all prior versions |
| 05_ROADMAP_v15.md | Phased execution plan with PKR revenue timeline + day-by-day schedule |
| 06_CLAUDE_MD_v15.md | AI agent working instructions v11 base + v13 Quick Reference Appendix |
| 07_BEGINNER_GUIDE_v15.md | Merged solo founder guide — Set B framing + Set A operational detail |
| 08_MISSING_SUGGESTED.md | Gap analysis — updated to reflect v15 resolutions |
| 09_BUILD_STATE_v15.md | Live tracking document — update every session |

---

## 7. PRODUCT POSITIONING (ENTERPRISE LAYER)

HOSTYLLO competes in a space where the most credible alternatives are:
- Generic ERP (Tally-style — complex, expensive, enterprise-only)
- Excel/WhatsApp manual management (90% of Pakistan's hostels today)
- Global platforms (not Pakistan-localized, no CNIC support, no Urdu, no JazzCash)

**Positioning Statement:** HOSTYLLO is the only platform that combines the familiarity of what Pakistani wardens already know (from the Electron app experience), the intelligence of AI-assisted operations, and the trust of enterprise-grade security — in a mobile-first, bilingual (Urdu/English), Pakistan-native SaaS.

**Long-term category:** AI-powered operational intelligence for accommodation businesses. The "Stripe" of hostel management — premium, trustworthy, operationally intelligent.

---

## 8. MERGE AUDIT — v13 FINDINGS

> This section appended from Set A (v13 gap-fill suite) — System Architect of Record audit findings.

### Key Findings from v13 Audit

1. **The Cloudberry PRDs are Unrelated to HOSTYLLO.** Two uploaded PRD files (`Cloudberry_PRD.docx`, `Cloudberry_PRD_1.docx`) are a completely separate project — a "Production-Ready Developer Suite" PRD from a Codeflare educational video. They have no connection to hostel management. Action: Ignore entirely.

2. **Nothing Is Built Yet.** Every task in the build state is ⬜ TODO. Phase 0 has not been completed. No code exists. The monorepo does not exist. The database does not exist. There are zero endpoints. The roadmap must start from literal zero.

3. **v13.0 Was the Authoritative PRD; v14.0 / v15.0 Supersede It.** The version hierarchy: v15.0 (this suite) ← v14.0 ← v13.0 ← v12.0 ← all ZIP archive versions.

4. **The Enterprise AI Prompt Conflicts with Solo Reality.** The master prompt instructs transformation into a "$100M SaaS company with AI analytics, predictive occupancy, AI assistants." The PRD explicitly defers all ML features to Phase 7+ (MRR trigger + hire required). Resolution: Architecture the AI vision as PHASES 7–8. In Phases 1–6, implement operationally intelligent features requiring zero ML infrastructure (rule-based smart defaults, alert banners, threshold warnings, WhatsApp automation).

5. **One Critical Missing File — Now Resolved.** The PRD referenced `04_UXDESIGN_SYSTEM.md` since v12/v13 but the file did not exist. **This is now resolved in v15: the file exists as `04_UX_DESIGN_SYSTEM.md`.**

6. **Brand Name is Canonical.** HOSTYLLO (not HOSTEX-Space). The Hostex branding in legacy folder names is a naming artifact. All new code and docs use HOSTYLLO.

---

### CONTRADICTION LOG

All contradictions between files, resolved:

| Contradiction | Files | Resolution |
|--------------|-------|------------|
| Phase count: 6 active vs 8 total | v12 had 8 phases; v13/v14 demote 7-8 to DEFERRED | v14/v15 wins: 6 active phases |
| Student portal phase | v12: Phase 6; v13+: DEFERRED Phase 7+ | v14/v15 wins: DEFERRED |
| Stripe/USD billing | v12: Phase 6; v13+: DEFERRED when MRR > PKR 500k | v14/v15 wins: DEFERRED |
| AI rent suggestion | v12: GAP-P08 Phase 2; v13+: DEFERRED Phase 7+ | v14/v15 wins: DEFERRED |
| "hostel_owner → chain_manager → warden → viewer" hierarchy | Both have it consistently | No contradiction |
| Table count | CLAUDE.md v9 says "22 tables"; v13+ says "28 tables" | v14/v15 wins: 28 tables |
| Brand name HOSTEX-Space vs HOSTYLLO | Old vs canonical | HOSTYLLO canonical; all artifacts use this |
| WhatsApp phase: Phase 1 copy-paste vs Phase 3 API | Both correct simultaneously | Copy-paste fallback Phase 1; API integration Phase 3 |

---

### PRODUCTION READINESS VERDICT

| Area | Status | Assessment |
|------|--------|------------|
| PRD Documentation | ✅ Complete | v15.0 is enterprise-grade |
| Security Architecture | ✅ Complete | 34 risks mitigated, 6 invariants |
| Database Design | ✅ Complete | 28 tables, RLS, withTenant() |
| Payment Logic | ✅ Complete | 14 unit tests, formula specified |
| Build Artifacts | ✅ Ready to use | hostyllo_fixes.zip has ESLint plugins, tests, CI YAML, verify-pitr.sh |
| CLAUDE.md for Claude Code | ✅ v15.0 | docs/06_CLAUDE_MD_v15.md — current and complete |
| UX Design System | ✅ NOW EXISTS | docs/04_UX_DESIGN_SYSTEM.md — GAP-1 resolved in v15 |
| Beginner Guide | ✅ v15.0 | docs/07_BEGINNER_GUIDE_v15.md — merged, complete |
| Build State | ✅ NOW EXISTS | docs/09_BUILD_STATE_v15.md — created in v15 suite |
| Actual Code | ❌ ZERO | Nothing is built |
| Infrastructure | ❌ NOT PROVISIONED | Phase 0 not completed |

---

*HOSTYLLO System Overview v15.0 · Synthesized May 2026 · Zeerak Hostix · Confidential*
*Synthesized from: PRD v14, v13 gap-fill suite, all prior archives*
