# HOSTYLLO — Missing & Suggested Files
## Gap Analysis · Recommended Additional Documents
## 08_MISSING_SUGGESTED.md
## v15.0 · May 2026

---

## 1. FILES THAT ALREADY EXIST (Across All Uploaded Archives)

| File | Source | Status in v14 Suite |
|------|--------|---------------------|
| 01_MASTER_PRD_v13.md | Uploaded directly | SUPERSEDED by 01_MASTER_PRD_v14.md |
| hostyllo_docs_v10/02_AGENT_BOOTSTRAP.md | hostyllo_docs_v10.zip | SUPERSEDED by 05_CLAUDE_MD_v11.md |
| hostyllo_docs_v10/03_ROADMAP.md | hostyllo_docs_v10.zip | SUPERSEDED by 04_ROADMAP_v14.md |
| hostyllo_docs_v10/04_ARCHITECTURE.md | hostyllo_docs_v10.zip | ABSORBED into 02_PRODUCT_BLUEPRINT.md |
| hostyllo_docs_v10/05_BUILD_STATE.md | hostyllo_docs_v10.zip | **KEEP — Active tracking file** |
| hostyllo_docs_v10/06_ISSUES_LOG.md | hostyllo_docs_v10.zip | **KEEP — Active issue tracking** |
| hostyllo_docs_v10/tasks/lessons.md | hostyllo_docs_v10.zip | **KEEP — Critical AI agent memory** |
| hostyllo_docs_v10/tasks/todo.md | hostyllo_docs_v10.zip | **KEEP — Per-session tracking** |
| hostyllo_fixes/tests/paymentService.test.ts | hostyllo_fixes.zip | **KEEP — Production test file** |
| hostyllo_fixes/infra/ci.yml | hostyllo_fixes.zip | **KEEP — Active CI pipeline** |
| hostyllo_fixes/infra/verify-pitr.sh | hostyllo_fixes.zip | **KEEP — Monthly ritual script** |
| hostyllo_fixes/eslint/* | hostyllo_fixes.zip | **KEEP — Production ESLint rules** |
| hostyllo_fixes/bullmq/BULLMQ_DLQ_SPEC.md | hostyllo_fixes.zip | **KEEP — Implementation spec** |
| hostyllo-claude-agents/.claude/commands/* | hostyllo-claude-agents.zip | **KEEP — Useful Claude Code commands** |
| Cloudberry_PRD.docx / Cloudberry_PRD_1.docx | Uploaded directly | **UNRELATED — Different product. Not integrated.** |

---

## 2. CRITICAL FILES MISSING FROM ALL UPLOADED DOCUMENTS

These files were referenced in the PRD and CLAUDE.md but never created. They are needed for production.

### 2.1 BUILD STATE v14 (RESOLVED in v15)
**File:** `docs/09_BUILD_STATE_v15.md`
**Status:** ✅ CREATED in v15 suite — `docs/09_BUILD_STATE_v15.md` exists and contains the Phase 0 checklist, Phase 1 Definition of Done, Decision Log, Lessons Log, and Last Session Summary template.

---

### 2.2 PAYMENT SERVICE TEST FILE (CRITICAL)
**File:** `packages/db/src/__tests__/paymentService.test.ts`
**Why Needed:** The 14-test file exists in `hostyllo_fixes/tests/paymentService.test.ts`. It needs to be placed at the correct monorepo path before any Phase 1 work begins. This is a non-negotiable gate.

**Action:** Copy from `hostyllo_fixes/tests/paymentService.test.ts` to `packages/db/src/__tests__/paymentService.test.ts`. Do not modify it.

---

### 2.3 DATABASE SCHEMA SQL (CRITICAL)
**File:** `packages/db/src/schema.sql`
**Why Needed:** PRD Section 17 defines 28 tables. The actual SQL has never been written into a single canonical file. Claude Code will need to generate this for Phase 1, but it must be verified against every PRD invariant before being applied to production.

**What It Needs:**
- All 28 table definitions
- All `NUMERIC(10,2)` for money columns
- All `deleted_at TIMESTAMPTZ` soft-delete columns
- All `hostel_id UUID NOT NULL REFERENCES hostels(hostel_id)`
- `ALTER TABLE x ENABLE ROW LEVEL SECURITY` for every table
- RLS policies using `current_setting('app.hostel_id')`
- All GIN indexes for `pg_trgm` search
- `get_next_receipt_number()` PL/pgSQL function
- Dashboard aggregation view

**Suggested Action:** Generate this as the FIRST task in Phase 1 using Claude Code. Have Claude generate it, then review every table against PRD Section 17 before applying.

---

### 2.4 PRIVACY POLICY + TERMS OF SERVICE (LEGAL — REQUIRED BEFORE PHASE 3)
**Files:** `apps/web/app/privacy/page.tsx`, `apps/web/app/terms/page.tsx`
**Why Needed:** PRD Section 34 (PDPA compliance) requires these to be live before any client onboards. The onboarding wizard (Step 1) has a mandatory Terms acceptance checkbox.

**What Privacy Policy Must Cover:**
- What PII is collected (CNIC, phone, student name, payment data)
- How CNIC is encrypted (AES-256, cannot be read without encryption key)
- Data retention periods (31 days after account deletion)
- Right to export all data (Settings → Export)
- Right to request deletion
- Super Admin impersonation disclosure
- Contact information for data requests

**Suggested Action:** Draft during Phase 2. Get reviewed before Phase 3. Do not launch self-serve without these.

---

### 2.5 DATA PROCESSING AGREEMENT (DPA) TEMPLATE (LEGAL)
**File:** `docs/legal/DPA_template.md`
**Why Needed:** PRD Section 34 requires a signed DPA with every paying client before student PII is uploaded. HOSTYLLO is a data processor; the hostel is the data controller.

**Key Clauses Needed:**
- Sub-processor list (Supabase for database, Railway for compute)
- Data residency (Mumbai region)
- Breach notification obligations (72-hour notice)
- CNIC encryption disclosure
- Deletion obligations on contract termination

**Suggested Action:** Create a simple 1-page template. Have a Pakistani lawyer review it before Phase 3 launch. Budget: PKR 20,000–50,000 for legal review.

---

### 2.6 UX DESIGN SYSTEM (RESOLVED in v15)
**File:** `docs/04_UX_DESIGN_SYSTEM.md`
**Status:** ✅ RESOLVED — included as `04_UX_DESIGN_SYSTEM.md` in v15 suite. This fills the critical GAP-1 referenced in every PRD version from v12.0 onward.

---

### 2.7 BUILD STATE v15 (RESOLVED)
**File:** `docs/09_BUILD_STATE_v15.md`
**Status:** ✅ CREATED in v15 suite

---

### 2.8 LOAD TEST SCRIPT (REQUIRED BEFORE PHASE 5)
**File:** `scripts/load-test.js`
**Why Needed:** PRD Section 43 and Roadmap Phase 5 require a k6 load test at 500 concurrent tenants (p95 < 200ms) before Phase 5 launches. This script does not exist anywhere in the uploaded files.

**What It Needs:**
- k6 script simulating 500 virtual users
- Scenarios: login, dashboard load, student search, payment recording
- Thresholds: p95 < 200ms, error rate < 1%
- Per-hostel data isolation verification under load

**Suggested Action:** Build during Phase 4 preparation. Test against staging environment. Do not test against production.

---

### 2.9 ONBOARDING FUNNEL TRACKING SCHEMA
**File:** Part of `packages/db/src/schema.sql`
**Why Needed:** PRD Section 29 requires all 7 wizard steps to track events to `onboarding_events` table. The table exists in the 28-table schema but the event schema (what events are tracked and with what payload) is not fully defined anywhere.

**What It Needs:**
```sql
-- Each wizard step fires one of these events:
-- wizard_step_1_complete, wizard_step_2_complete, ..., wizard_complete

CREATE TABLE onboarding_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  hostel_id UUID NOT NULL REFERENCES hostels(hostel_id),
  event_name VARCHAR(50) NOT NULL, -- e.g., 'wizard_step_1_complete'
  step_number INTEGER,
  completed_at TIMESTAMPTZ DEFAULT now(),
  metadata JSONB -- any additional context
);
```

**Suggested Action:** Include in Migration 006 (product tables). Super Admin onboarding funnel chart reads from this table.

---

### 2.10 RECEIPT HTML TEMPLATE (REQUIRED FOR PHASE 1)
**File:** `packages/db/src/receiptService.ts`
**Why Needed:** PRD Section 09 (FR-PAY-05) specifies the exact receipt format. The Electron app's `buildReceiptHTML()` must be ported verbatim. This function doesn't exist in any uploaded file.

**What It Must Include:**
- Hostel logo + name + tagline
- Sequential receipt number (from `get_next_receipt_number()`)
- Student name + masked CNIC (XXXXX-XXXXXXX-X format)
- Room number
- Month
- Fee breakdown: Rent | Admission Fee | Extra Charges (itemized) | Concession | Total Due | Paid | Balance
- Payment method
- Due date
- Warden signature area
- "Generated by HOSTYLLO" footer (small, can be disabled on Enterprise)

**Suggested Action:** Generate this in Phase 1 Week 12. Port the HTML structure from the Electron app if Zeerak has access to the original app.js receipt function.

---

## 3. SUGGESTED NEW FILES (Not in Any Uploaded Document)

These files don't exist anywhere in the uploaded archives but would meaningfully improve production readiness.

### 3.1 INCIDENT RUNBOOK
**File:** `docs/INCIDENT_RUNBOOK.md`
**Why Suggested:** When production breaks at 2am, you need a step-by-step guide, not your memory.

**Would Cover:**
- P0 incident response (data loss/formula error/outage): exact steps
- P1 incident (login broken): exact commands to run
- "My Supabase is down": how to check, who to contact
- "Client says receipt is wrong": how to verify formula, how to regenerate
- Railway API unresponsive: health check commands, how to restart
- Redis down: what degrades gracefully, what breaks hard

---

### 3.2 CLIENT ONBOARDING CHECKLIST
**File:** `docs/CLIENT_ONBOARDING.md`
**Why Suggested:** PRD Section 32 requires specific documentation for wardens before the first client is onboarded. This checklist ensures you don't miss anything when bringing on a real client.

**Would Cover:**
- Pre-onboarding: DPA signed, WhatsApp group created
- Technical setup: hostel created, owner account created
- Data migration: help them import their student list from Excel
- Training session: screen share → add student → record payment → generate receipt
- Confirmation: client confirms "I can do this on my own now"
- Post-onboarding: 48-hour check-in call

---

### 3.3 WARDEN USER MANUAL (URDU + ENGLISH)
**File:** `docs/WARDEN_MANUAL.md`
**Why Suggested:** PRD Section 32 specifically requires: "The following documentation must exist and be tested with a real non-technical user BEFORE the first live client is onboarded."

**Required Content:**
1. How to add a student (step-by-step with screenshots)
2. How to record a payment and share a WhatsApp receipt
3. How to run the monthly defaulters list and send bulk reminders
4. How to bulk-import students from Excel
5. What to do if the app shows an error
6. How to export all data from Settings

---

### 3.4 SECURITY INCIDENT RESPONSE PLAN
**File:** `docs/SECURITY_INCIDENT_PLAN.md`
**Why Suggested:** PRD Section 19 defines 34 security risks but doesn't define what to do if one actually occurs. Given CNIC data is stored (even encrypted), a breach response plan is a PDPA obligation.

**Would Cover:**
- Breach detection (what Sentry/Cloudflare alerts mean)
- Containment: how to immediately block access
- Assessment: how to determine scope of breach
- Notification: Pakistan PDPA requires notification to affected parties
- Remediation: steps to close the vulnerability
- Communication template for affected clients

---

### 3.5 ENVIRONMENT SETUP SCRIPT
**File:** `scripts/setup-dev.sh`
**Why Suggested:** Setting up a new development environment or onboarding yourself after a break requires remembering many steps. A script eliminates this.

**Would Include:**
```bash
#!/bin/bash
# HOSTYLLO Development Environment Setup
# Run once on a new machine or after wiping node_modules

echo "Setting up HOSTYLLO development environment..."

# Check prerequisites
command -v node >/dev/null || { echo "Node.js required"; exit 1; }
command -v pnpm >/dev/null || npm install -g pnpm

# Install dependencies
pnpm install

# Copy env template
cp .env.example .env.local
echo "⚠️  Edit .env.local with your credentials before running"

# Verify PITR
./scripts/verify-pitr.sh

echo "Setup complete. Run: pnpm dev"
```

---

## 4. FILES FROM UPLOADED ARCHIVES THAT SHOULD BE MIGRATED

These files exist in the ZIP archives and contain valuable production-ready code that should be placed at the correct monorepo paths:

| Source Path (in ZIP) | Target Path (in Monorepo) | Why Important |
|---------------------|--------------------------|---------------|
| `hostyllo_fixes/tests/paymentService.test.ts` | `packages/db/src/__tests__/paymentService.test.ts` | Production test suite — 14 tests |
| `hostyllo_fixes/infra/ci.yml` | `.github/workflows/ci.yml` | Production CI pipeline |
| `hostyllo_fixes/infra/verify-pitr.sh` | `scripts/verify-pitr.sh` | Monthly PITR verification ritual |
| `hostyllo_fixes/eslint/eslint-plugin-hostyllo/rules/require-with-tenant.js` | `packages/config/eslint-plugin-hostyllo/rules/require-with-tenant.js` | CI-enforced isolation rule |
| `hostyllo_fixes/eslint/eslint-plugin-hostyllo/rules/no-hostel-id-from-request.js` | `packages/config/eslint-plugin-hostyllo/rules/no-hostel-id-from-request.js` | CI-enforced IDOR prevention |
| `hostyllo_fixes/bullmq/BULLMQ_DLQ_SPEC.md` | `docs/BULLMQ_DLQ_SPEC.md` | BullMQ implementation reference |
| `hostyllo-claude-agents/.claude/commands/security.md` | `.claude/commands/security.md` | Useful for security reviews in Claude Code |
| `hostyllo-claude-agents/.claude/commands/architect.md` | `.claude/commands/architect.md` | Useful for architecture decisions in Claude Code |
| `hostyllo-claude-agents/.claude/commands/db.md` | `.claude/commands/db.md` | Useful for database work in Claude Code |

---

## 5. WHAT TO DO NEXT (Priority Order)

| Priority | Action | Time | Blocks |
|---------|--------|------|--------|
| 🔴 IMMEDIATE | Migrate `paymentService.test.ts` to correct monorepo path | 5 min | Phase 1 cannot start without these tests |
| 🔴 IMMEDIATE | Migrate `ci.yml`, `verify-pitr.sh`, ESLint rules to monorepo | 30 min | Phase 0 exit requires these |
| 🔴 IMMEDIATE | Update `05_BUILD_STATE.md` to v14.0 task list | 20 min | Claude Code needs accurate build state |
| 🟡 PHASE 1 | Generate `schema.sql` as first Phase 1 task | 2-3 hours | All DB migrations |
| 🟡 PHASE 1 | Port `buildReceiptHTML()` from Electron app | 2 hours | PDF receipt generation |
| 🟡 PHASE 2 | Draft Privacy Policy and Terms of Service | 4 hours | Phase 3 launch |
| 🟡 PHASE 2 | Create warden user manual (screenshot guide) | 1 day | First client onboarding |
| 🔵 PHASE 3 | DPA template with Pakistani lawyer review | PKR 20-50k | Enterprise client contracts |
| 🔵 PHASE 4 | Load test script for k6 | 2 hours | Phase 5 launch gate |
| 🔵 PHASE 4 | Incident runbook | 2 hours | Operational maturity |

---

*HOSTYLLO Missing & Suggested Files v15.0 · May 2026 · Confidential*
